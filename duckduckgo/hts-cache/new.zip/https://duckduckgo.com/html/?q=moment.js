<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<!--[if IE 6]><html class="ie6" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if IE 7]><html class="lt-ie8 lt-ie9" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if IE 8]><html class="lt-ie9" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if gt IE 8]><!--><html xmlns="http://www.w3.org/1999/xhtml"><!--<![endif]-->
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=1" />
  <meta name="referrer" content="origin" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="robots" content="noindex, nofollow" />
  <title>moment.js at DuckDuckGo</title>
  <link title="DuckDuckGo (HTML)" type="application/opensearchdescription+xml" rel="search" href="/opensearch_html.xml" />
  <link href="/favicon.ico" rel="shortcut icon" />
  <link rel="apple-touch-icon" href="/assets/logo_icon128.v101.png"/>
  <link rel="image_src" href="/assets/logo_homepage.normal.v101.png"/>  
  <link type="text/css" media="handheld, all" href="/h1224.css" rel="stylesheet" />
</head>

<body class="body--html">
  <a name="top" id="top"></a>

  <form action="/html/" method="post">
    <input type="text" name="state_hidden" id="state_hidden" />
  </form>

  <div>
    <div class="site-wrapper-border"></div>

    <div id="header" class="header cw header--html">
        <a title="DuckDuckGo" href="/html/" class="header__logo-wrap"></a>


    <form name="x" class="header__form" action="/html/" method="post">

      <div class="search search--header">
          <input name="q" autocomplete="off" class="search__input" id="search_form_input_homepage" type="text" value="moment.js" />
          <input name="b" id="search_button_homepage" class="search__button search__button--html" value="" title="Search" alt="Search" type="submit" />
      </div>


        
        
        
        
        

    
    
      <input name="kl" value="us-en" type="hidden" />
        
        
    </form>

    </div>


<!-- If zero click results are present -->
    <div class="zci-wrapper">
      <div class="zci">
        <h1 class="zci__heading">
              <a rel="nofollow" href="https://en.wikipedia.org/wiki/Moment.js">Moment.js</a>
        </h1>


          <div class="zci__result" id="zero_click_abstract">

  



            Moment.js is a cross-platform JavaScript library for parsing, validating, manipulating and formatting dates. Moment.js is free, open source software, licensed under the MIT License.
            
            <a rel="nofollow" href="https://en.wikipedia.org/wiki/Moment.js" >More at <q>Wikipedia</q></a>
          
          </div>

      </div>
    </div>




<!-- Web results are present -->

  <div>
  <div class="results-wrapper">
  <div id="links" class="results">

      



  

    

        <div class="result results_links results_links_deep result--ad ">

          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTc4NTEzNDU0MiZsdD0yJmVzPUtjU0pwMU1HUFM5c0ZfTlc-/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3eiZ0oqCX93X8eQqYchMOWzVUCUwwKc3r4-5LlRr_GLk-Z7wSoMUC-a7A-rUpa3j_RUPxYBL9TuaRB_YbC2T7oYdlo9EK-vXUz6gxy5eLGUWawY2qi1YfpIq8kHcklrMaF4p3BpXhBM4u4u2rCLOazAAmvy0%26u%3dwww.PersonalizationMall.com%252fBest-Selling-Gifts-for-Women-Best-Selling-Mothers-Day-Gifts-d1226.dept%253fstoreID%253d19%2526did%253d140582%2526utm_source%253dmsn_adcenter%2526utm_medium%253dcpc/RK=0/RS=aDRzYqawchCFJ_BOzSut3bXs6Vg-">Huge Mother Gifts Sale</a>
          
            <a class="result__badge  badge--ad" href="https://duck.co/help/company/advertising-and-affiliates">Ad</a>
          </h2>

          

      
            <a class="result__snippet" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTc4NTEzNDU0MiZsdD0yJmVzPUtjU0pwMU1HUFM5c0ZfTlc-/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3eiZ0oqCX93X8eQqYchMOWzVUCUwwKc3r4-5LlRr_GLk-Z7wSoMUC-a7A-rUpa3j_RUPxYBL9TuaRB_YbC2T7oYdlo9EK-vXUz6gxy5eLGUWawY2qi1YfpIq8kHcklrMaF4p3BpXhBM4u4u2rCLOazAAmvy0%26u%3dwww.PersonalizationMall.com%252fBest-Selling-Gifts-for-Women-Best-Selling-Mothers-Day-Gifts-d1226.dept%253fstoreID%253d19%2526did%253d140582%2526utm_source%253dmsn_adcenter%2526utm_medium%253dcpc/RK=0/RS=aDRzYqawchCFJ_BOzSut3bXs6Vg-">30% Off Personalized Gifts for Mom! Free Engraving, Fast Shipping.</a>
      

            
            <div class="result__extras">
                <div class="result__extras__url">

<!-- Disable Ad Favicon
                  <span class="result__icon">
                    
                      <a rel="nofollow" class="result__icon__img" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTc4NTEzNDU0MiZsdD0yJmVzPUtjU0pwMU1HUFM5c0ZfTlc-/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3eiZ0oqCX93X8eQqYchMOWzVUCUwwKc3r4-5LlRr_GLk-Z7wSoMUC-a7A-rUpa3j_RUPxYBL9TuaRB_YbC2T7oYdlo9EK-vXUz6gxy5eLGUWawY2qi1YfpIq8kHcklrMaF4p3BpXhBM4u4u2rCLOazAAmvy0%26u%3dwww.PersonalizationMall.com%252fBest-Selling-Gifts-for-Women-Best-Selling-Mothers-Day-Gifts-d1226.dept%253fstoreID%253d19%2526did%253d140582%2526utm_source%253dmsn_adcenter%2526utm_medium%253dcpc/RK=0/RS=aDRzYqawchCFJ_BOzSut3bXs6Vg-">
                        <img width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/https://s.yimg.com/pp/favicons-new/20131101/personalizationmall.com.png.ico" name="i15" />
                      </a>
                  
                  </span>
-->

                  <a class="result__url" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTc4NTEzNDU0MiZsdD0yJmVzPUtjU0pwMU1HUFM5c0ZfTlc-/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3eiZ0oqCX93X8eQqYchMOWzVUCUwwKc3r4-5LlRr_GLk-Z7wSoMUC-a7A-rUpa3j_RUPxYBL9TuaRB_YbC2T7oYdlo9EK-vXUz6gxy5eLGUWawY2qi1YfpIq8kHcklrMaF4p3BpXhBM4u4u2rCLOazAAmvy0%26u%3dwww.PersonalizationMall.com%252fBest-Selling-Gifts-for-Women-Best-Selling-Mothers-Day-Gifts-d1226.dept%253fstoreID%253d19%2526did%253d140582%2526utm_source%253dmsn_adcenter%2526utm_medium%253dcpc/RK=0/RS=aDRzYqawchCFJ_BOzSut3bXs6Vg-">
                  personalizationmall.com
                  </a>

                  

                </div>
            </div>
            


        <div style="clear: both"></div>
          </div>


        </div>

    

  



  

    

        <div class="result results_links results_links_deep result--ad result--ad--small">

          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTg5MjkxNDA4MTUmbHQ9MiZlcz1vaUJlQkRnR1BTOE1SdG8u/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3_XLMZaCZy0dvhqlHvD6S9DVUCUzuK7whx6pLsHjd4UXRyW8XaVK-s3KGKNdogXsWvtEx7s06bIz-XF1MwMgxmt3TMgNQvu0fIcKBSvvh5zULrU0lohkN-jPMmUPDFAj8FwkqH7a6atxmBpVzTv2HDRtypzU%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dovercoming%252bsenior%252bmoments%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d8929140815%2526hvqmt%253db%2526hvbmt%253dbb%2526hvdev%253dc%2526ref%253dpd_sl_6gi3292vde_b/RK=0/RS=PvfjvqKs7m1du_fevLn.2BTxhE4-">Books - Amazon.ca</a>
          
            <a class="result__badge  badge--ad" href="https://duck.co/help/company/advertising-and-affiliates">Ad</a>
          </h2>

          
              <a class="result__url sep--after" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTg5MjkxNDA4MTUmbHQ9MiZlcz1vaUJlQkRnR1BTOE1SdG8u/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3_XLMZaCZy0dvhqlHvD6S9DVUCUzuK7whx6pLsHjd4UXRyW8XaVK-s3KGKNdogXsWvtEx7s06bIz-XF1MwMgxmt3TMgNQvu0fIcKBSvvh5zULrU0lohkN-jPMmUPDFAj8FwkqH7a6atxmBpVzTv2HDRtypzU%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dovercoming%252bsenior%252bmoments%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d8929140815%2526hvqmt%253db%2526hvbmt%253dbb%2526hvdev%253dc%2526ref%253dpd_sl_6gi3292vde_b/RK=0/RS=PvfjvqKs7m1du_fevLn.2BTxhE4-">
              amazon.ca
              </a>
          

      
            <a class="result__snippet" href="https://r.search.yahoo.com/cbclk/dWU9QTA5OThCMUU2MkM5NDQzRCZ1dD0xNDc5OTgxOTgxNDI3JnVvPTg5MjkxNDA4MTUmbHQ9MiZlcz1vaUJlQkRnR1BTOE1SdG8u/RV=2/RE=1480010781/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3_XLMZaCZy0dvhqlHvD6S9DVUCUzuK7whx6pLsHjd4UXRyW8XaVK-s3KGKNdogXsWvtEx7s06bIz-XF1MwMgxmt3TMgNQvu0fIcKBSvvh5zULrU0lohkN-jPMmUPDFAj8FwkqH7a6atxmBpVzTv2HDRtypzU%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dovercoming%252bsenior%252bmoments%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d8929140815%2526hvqmt%253db%2526hvbmt%253dbb%2526hvdev%253dc%2526ref%253dpd_sl_6gi3292vde_b/RK=0/RS=PvfjvqKs7m1du_fevLn.2BTxhE4-">Free 2-Day Shipping w/Amazon Prime</a>
      

            


        <div style="clear: both"></div>
          </div>


        </div>

    

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://momentjs.com/"><b>Moment.js</b> | Home</a>
          
          </h2>

      
            <a class="result__snippet" href="http://momentjs.com/">siSwati <b>Moment.js</b> is freely distributable under the terms of the MIT license.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://momentjs.com/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/momentjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://momentjs.com/">
                  momentjs.com
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://momentjs.com/docs/"><b>Moment.js</b> | Docs</a>
          
          </h2>

      
            <a class="result__snippet" href="http://momentjs.com/docs/">Moment was designed to work both in the browser and in Node.js. All code should work in both of these environments, and all unit tests are run in both of these ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://momentjs.com/docs/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/momentjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://momentjs.com/docs/">
                  momentjs.com/docs/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://stackoverflow.com/questions/10967736/how-to-use-moment-js">javascript - How to use <b>Moment.js</b>? - Stack Overflow</a>
          
          </h2>

      
            <a class="result__snippet" href="http://stackoverflow.com/questions/10967736/how-to-use-moment-js">I&#x27;m unable to follow the <b>Moment.js</b> documentation, and need some help with setting it up. I&#x27;ve referenced the moment.min.js file properly on my webpage like so: &lt; ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://stackoverflow.com/questions/10967736/how-to-use-moment-js">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/stackoverflow.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://stackoverflow.com/questions/10967736/how-to-use-moment-js">
                  stackoverflow.com/questions/10967736/how-to-use-moment-js
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://stackoverflow.com/questions/15993913/format-date-with-moment-js">javascript - format date with <b>moment.js</b> - Stack Overflow</a>
          
          </h2>

      
            <a class="result__snippet" href="http://stackoverflow.com/questions/15993913/format-date-with-moment-js">I have a string in this format: var testDate = Fri Apr 12 2013 19:08:55 GMT-0500 (CDT) I would like to using <b>moment.js</b> get it in this format mm/dd/yyyy ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://stackoverflow.com/questions/15993913/format-date-with-moment-js">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/stackoverflow.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://stackoverflow.com/questions/15993913/format-date-with-moment-js">
                  stackoverflow.com/questions/15993913/format-date-with-momen...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://github.com/moment/moment">GitHub - moment/moment: Parse, validate, manipulate, and display dates ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://github.com/moment/moment">moment - Parse, validate, manipulate, and display dates in javascript. Skip to content. ... <b>Moment.js</b> is freely distributable under the terms of the MIT license.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://github.com/moment/moment">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/github.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://github.com/moment/moment">
                  github.com/moment/moment
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.sitepoint.com/managing-dates-times-using-moment-js/">Managing Dates and Times Using <b>Moment.js</b> - SitePoint</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.sitepoint.com/managing-dates-times-using-moment-js/">This article introduces <b>Moment.js</b>, a JavaScript library for working with dates and times.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.sitepoint.com/managing-dates-times-using-moment-js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.sitepoint.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.sitepoint.com/managing-dates-times-using-moment-js/">
                  sitepoint.com/managing-dates-times-using-moment-js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.nuget.org/packages/Moment.js/">NuGet Gallery | <b>Moment.js</b> 2.16.0</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.nuget.org/packages/Moment.js/">Contact Us. Got questions about NuGet or the NuGet Gallery? Overview. NuGet is a Visual Studio extension that makes it easy to add, remove, and update libraries and...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.nuget.org/packages/Moment.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.nuget.org.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.nuget.org/packages/Moment.js/">
                  nuget.org/packages/Moment-js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.techrepublic.com/blog/software-engineer/momentjs-simplifies-working-with-date-values-in-javascript/"><b>Moment.js</b> simplifies working with date values in JavaScript</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.techrepublic.com/blog/software-engineer/momentjs-simplifies-working-with-date-values-in-javascript/">The lightweight JavaScript library <b>Moment.js</b> makes working with date and time values a breeze.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.techrepublic.com/blog/software-engineer/momentjs-simplifies-working-with-date-values-in-javascript/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.techrepublic.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.techrepublic.com/blog/software-engineer/momentjs-simplifies-working-with-date-values-in-javascript/">
                  techrepublic.com/blog/software-engineer/momentjs-simplifie...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://github.com/urish/angular-moment">GitHub - urish/angular-moment: <b>Moment.JS</b> directives for Angular.JS ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://github.com/urish/angular-moment">angular-moment - <b>Moment.JS</b> directives for Angular.JS (timeago and more)</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://github.com/urish/angular-moment">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/github.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://github.com/urish/angular-moment">
                  github.com/urish/angular-moment
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://atmospherejs.com/momentjs/moment"><b>Moment</b> <b>JS</b> - Atmosphere</a>
          
          </h2>

      
            <a class="result__snippet" href="https://atmospherejs.com/momentjs/moment">Atmosphere is the catalog for Meteor packages, resources and tools. Explore the most popular, trusted, and reliable packages to install in your apps.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://atmospherejs.com/momentjs/moment">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/atmospherejs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://atmospherejs.com/momentjs/moment">
                  atmospherejs.com/momentjs/moment
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://cdnjs.com/libraries/moment.js/"><b>moment.js</b> - cdnjs.com - The best FOSS CDN for web related libraries to ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://cdnjs.com/libraries/moment.js/"><b>moment.js</b> - Parse, validate, manipulate, and display dates - cdnjs.com - The best FOSS CDN for web related libraries to speed up your websites!</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://cdnjs.com/libraries/moment.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/cdnjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://cdnjs.com/libraries/moment.js/">
                  cdnjs.com/libraries/moment-js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://jsfiddle.net/FLhpq/4/light/"><b>Moment</b> <b>JS,</b> UTC to Local time - JSFiddle</a>
          
          </h2>

      
            <a class="result__snippet" href="http://jsfiddle.net/FLhpq/4/light/">Test your JavaScript, CSS, HTML or CoffeeScript online with JSFiddle code editor.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://jsfiddle.net/FLhpq/4/light/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/jsfiddle.net.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://jsfiddle.net/FLhpq/4/light/">
                  jsfiddle.net/FLhpq/4/light/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://sixrevisions.com/tutorials/javascript-dates-moment-js/">Working with JavaScript Dates Using <b>Moment.js</b></a>
          
          </h2>

      
            <a class="result__snippet" href="http://sixrevisions.com/tutorials/javascript-dates-moment-js/">Date manipulation is one of those development hurdles that we all must jump at one point in our career, and great tools go a long way in taming the beast. The Moment ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://sixrevisions.com/tutorials/javascript-dates-moment-js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/sixrevisions.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://sixrevisions.com/tutorials/javascript-dates-moment-js/">
                  sixrevisions.com/tutorials/javascript-dates-moment-js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.va.gov/TRM/ToolPage.asp?tid=8855"><b>Moment.js</b> - United States Department of Veterans Affairs</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.va.gov/TRM/ToolPage.asp?tid=8855">One-VA Technical Reference Model Home Page ... Technologies must be operated and maintained in accordance with Federal and Department security and privacy policies ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.va.gov/TRM/ToolPage.asp?tid=8855">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.va.gov.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.va.gov/TRM/ToolPage.asp?tid=8855">
                  va.gov/TRM/ToolPage-asp?tid=8855
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.npmjs.com/package/moment"><b>Moment.js</b> on npm</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.npmjs.com/package/moment">Parse, validate, manipulate, and display dates ... Private packages for the whole team. It&#x27;s never been easier to manage developer teams with varying permissions ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.npmjs.com/package/moment">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.npmjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.npmjs.com/package/moment">
                  npmjs.com/package/moment
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://atmospherejs.com/momentjs/moment#!">momentjs:moment package | Atmosphere</a>
          
          </h2>

      
            <a class="result__snippet" href="https://atmospherejs.com/momentjs/moment#!">momentjs:moment <b>Moment.js</b> (official): parse, validate, manipulate, and display dates - official Meteor packaging</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://atmospherejs.com/momentjs/moment#!">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/atmospherejs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://atmospherejs.com/momentjs/moment#!">
                  atmospherejs.com/momentjs/moment#!
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://code.runnable.com/Um0fYqDLgQlNAAXE/use-moment-js-to-format-time">Use <b>moment.js</b> to format time Code Example - Runnable</a>
          
          </h2>

      
            <a class="result__snippet" href="http://code.runnable.com/Um0fYqDLgQlNAAXE/use-moment-js-to-format-time">Use <b>moment.js</b> to format time Code Example - Runnable ... <b>moment.js</b> Related Code. How to Make a Digital Clock with jQuery &amp; CSS3 Use <b>moment.js</b> to parse time</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://code.runnable.com/Um0fYqDLgQlNAAXE/use-moment-js-to-format-time">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/code.runnable.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://code.runnable.com/Um0fYqDLgQlNAAXE/use-moment-js-to-format-time">
                  code.runnable.com/Um0fYqDLgQlNAAXE/use-moment-js-to-format-...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.htmlgoodies.com/html5/javascript/a-roundup-of-popular-javascript-date-parsing-libraries-moment.js.html">A Roundup of Popular JavaScript Date Parsing Libraries: <b>Moment.js</b></a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.htmlgoodies.com/html5/javascript/a-roundup-of-popular-javascript-date-parsing-libraries-moment.js.html">While writing an article on Date Parsing using JavaScript and Regular Expressions I was delighted to discover a bunch of JavaScript libraries that simplify working ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.htmlgoodies.com/html5/javascript/a-roundup-of-popular-javascript-date-parsing-libraries-moment.js.html">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.htmlgoodies.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.htmlgoodies.com/html5/javascript/a-roundup-of-popular-javascript-date-parsing-libraries-moment.js.html">
                  htmlgoodies.com/html5/javascript/a-roundup-of-popular-jav...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.keycdn.com/support/moment-js-cdn/">Using a <b>Moment.js</b> CDN Combination - KeyCDN Support</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.keycdn.com/support/moment-js-cdn/">Use a <b>Moment.js</b> CDN combination to help deliver your <b>Moment.js</b> libraries FASTER. Visitors will receive assets via the closest CDN server. Learn more.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.keycdn.com/support/moment-js-cdn/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.keycdn.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.keycdn.com/support/moment-js-cdn/">
                  keycdn.com/support/moment-js-cdn/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://gist.github.com/founddrama/2182389"><b>Moment.js</b> examples · GitHub</a>
          
          </h2>

      
            <a class="result__snippet" href="https://gist.github.com/founddrama/2182389">How can I pass parameters to <b>moment</b> <b>js</b> ? var a = moment(&#x27;2016-06-06T21:03:55&#x27;);//now var b = moment(&#x27;2016-05-06T20:03:55&#x27;); console.log(a.diff(b, &#x27;minutes&#x27;)) // 44700</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://gist.github.com/founddrama/2182389">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/gist.github.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://gist.github.com/founddrama/2182389">
                  gist.github.com/founddrama/2182389
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://cdnjs.com/">cdnjs.com - The best FOSS CDN for web related libraries to speed up ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://cdnjs.com/">cdnjs.com - The best FOSS CDN for web related libraries to speed up your websites! Star CDNJS! cdnjs; Request a lib; Chat; Network; Uptime; git stats . main repo; git ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://cdnjs.com/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/cdnjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://cdnjs.com/">
                  cdnjs.com
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.c-sharpcorner.com/UploadFile/abhijmk/moment-js/">A New JavaScript Library to Manipulate Date ( <b>Moment.js</b>)</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.c-sharpcorner.com/UploadFile/abhijmk/moment-js/">A New JavaScript Library to Manipulate Date ( <b>Moment.js</b>) By Abhishek Goswami on Jul 19 2013. This library provides a very easy way to manipulate dates and times. 1. Like;</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.c-sharpcorner.com/UploadFile/abhijmk/moment-js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.c-sharpcorner.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.c-sharpcorner.com/UploadFile/abhijmk/moment-js/">
                  c-sharpcorner.com/UploadFile/abhijmk/moment-js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://guides.emberjs.com/v1.10.0/cookbook/user_interface_and_interaction/displaying_formatted_dates_with_moment_js/">Displaying Formatted Dates With <b>Moment.js</b> - Ember.js</a>
          
          </h2>

      
            <a class="result__snippet" href="https://guides.emberjs.com/v1.10.0/cookbook/user_interface_and_interaction/displaying_formatted_dates_with_moment_js/">Let&#x27;s look at another example. Say you need to create a simple control that allows you to type in a date and a date format. The date will be formatted accordingly ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://guides.emberjs.com/v1.10.0/cookbook/user_interface_and_interaction/displaying_formatted_dates_with_moment_js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/guides.emberjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://guides.emberjs.com/v1.10.0/cookbook/user_interface_and_interaction/displaying_formatted_dates_with_moment_js/">
                  guides.emberjs.com/v1.10.0/cookbook/user_interface_and_inter...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.quora.com/topic/MomentJS?share=1"><b>MomentJS</b> - Quora</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.quora.com/topic/MomentJS?share=1">This page may be out of date. Save your draft before refreshing this page. Submit any pending changes before refreshing this page.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.quora.com/topic/MomentJS?share=1">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.quora.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.quora.com/topic/MomentJS?share=1">
                  quora.com/topic/MomentJS?share=1
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://makingsense.github.io/moment-datepicker/">Moment Datepicker - GitHub Pages</a>
          
          </h2>

      
            <a class="result__snippet" href="https://makingsense.github.io/moment-datepicker/">Moment Datepicker is ready to work with Knockout, TypeScript and NuGet. It uses <b>Moment.js</b> to parse dates and to localize the literals, and Twitter-Bootstrap ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://makingsense.github.io/moment-datepicker/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/makingsense.github.io.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://makingsense.github.io/moment-datepicker/">
                  makingsense.github.io/moment-datepicker/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.npmjs.com/package/momentjs"><b>momentjs</b> - npmjs.com</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.npmjs.com/package/momentjs">If you want to install the <b>Moment.js</b> library, then use the moment package instead.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.npmjs.com/package/momentjs">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.npmjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.npmjs.com/package/momentjs">
                  npmjs.com/package/momentjs
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://twitter.com/momentjs"><b>moment.js</b> (@<b>momentjs</b>) | Twitter</a>
          
          </h2>

      
            <a class="result__snippet" href="https://twitter.com/momentjs">The latest Tweets from <b>moment.js</b> (@<b>momentjs</b>). A javascript date library for parsing, validating, manipulating, and formatting dates</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://twitter.com/momentjs">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/twitter.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://twitter.com/momentjs">
                  twitter.com/momentjs
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.devcurry.com/2013/08/using-jquery-and-momentjs-in-aspnet-mvc.html">Using jQuery and <b>Moment.js</b> in ASP.NET MVC to do Custom Unobtrusive Date ...</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.devcurry.com/2013/08/using-jquery-and-momentjs-in-aspnet-mvc.html">Using jQuery and <b>Moment.js</b> in ASP.NET MVC to do Custom Unobtrusive Date Comparison and Validation</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.devcurry.com/2013/08/using-jquery-and-momentjs-in-aspnet-mvc.html">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.devcurry.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.devcurry.com/2013/08/using-jquery-and-momentjs-in-aspnet-mvc.html">
                  devcurry.com/2013/08/using-jquery-and-momentjs-in-aspn...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://blog.skylight.io/bringing-sanity-to-javascript-utc-dates-with-moment-js-and-ember-data/">Bringing Sanity to JavaScript UTC Dates with <b>Moment.js</b> and Ember Data</a>
          
          </h2>

      
            <a class="result__snippet" href="http://blog.skylight.io/bringing-sanity-to-javascript-utc-dates-with-moment-js-and-ember-data/">25 Sep 2014 Bringing Sanity to JavaScript UTC Dates with <b>Moment.js</b> and Ember Data. One &quot;neat&quot; (awful) feature in JavaScript is that it automatically changes dates to ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://blog.skylight.io/bringing-sanity-to-javascript-utc-dates-with-moment-js-and-ember-data/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/blog.skylight.io.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://blog.skylight.io/bringing-sanity-to-javascript-utc-dates-with-moment-js-and-ember-data/">
                  blog.skylight.io/bringing-sanity-to-javascript-utc-dates-w...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://allmychanges.com/p/javascript/moment.js/">javascript/moment.js&#x27;s changelog at AllMyChanges.com, release notes tracker</a>
          
          </h2>

      
            <a class="result__snippet" href="https://allmychanges.com/p/javascript/moment.js/">Moment.Js&#x27;s release notes. user-friendly date formatting. AllMyChanges.com . Login with: GitHub or Twitter. Add New; Catalogue; FAQ; Help; All → javascript →</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://allmychanges.com/p/javascript/moment.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/allmychanges.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://allmychanges.com/p/javascript/moment.js/">
                  allmychanges.com/p/javascript/moment-js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  




        
        
                <div class="nav-link">
        <form action="/html/" method="post">
          <input type="submit" class='btn btn--alt' value="Next" />
          <input type="hidden" name="q" value="moment.js" />
          <input type="hidden" name="s" value="30" />
          <input type="hidden" name="nextParams" value="Keywords=moment.js&amp;xargs=12KPjg1slSrZquh831MeKMQeGUgRpd1tm58d0uXsYsfIwUpX9v6dFIEOacyZA6QO1xt77k%5FcDYpflNaKymwfaJExjXBRHcX726gZS7%5FYsrb%2DeWZZIezeZgn7Sy2tkTZXIFYk%2DBSQ%2E%2E&amp;hData=12KPjg1qdOxJy7tuqnF9W2TOSj8m4%2E" />
          <input type="hidden" name="v" value="l" />
          <input type="hidden" name="o" value="json" />
          <input type="hidden" name="dc" value="33" />
          <input type="hidden" name="api" value="/d.js" />

            
            
        
          <input name="kl" value="us-en" type="hidden" />
            
            
            
            
            
        </form>
                </div>
        



        <div class=" feedback-btn">
            <a rel="nofollow" href="/feedback.html" target="_new">Feedback</a>
        </div>
        <div style="clear:both;"></div>
  </div>
  </div> <!-- links wrapper //--> 

    



    </div>
  </div>




    <div id="bottom_spacing2"></div>

    
      <img src="/t/sl_h"/>
    

</body>
</html>
