<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<!--[if IE 6]><html class="ie6" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if IE 7]><html class="lt-ie8 lt-ie9" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if IE 8]><html class="lt-ie9" xmlns="http://www.w3.org/1999/xhtml"><![endif]-->
<!--[if gt IE 8]><!--><html xmlns="http://www.w3.org/1999/xhtml"><!--<![endif]-->
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=1" />
  <meta name="referrer" content="origin" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="robots" content="noindex, nofollow" />
  <title>mustache.js at DuckDuckGo</title>
  <link title="DuckDuckGo (HTML)" type="application/opensearchdescription+xml" rel="search" href="/opensearch_html.xml" />
  <link href="/favicon.ico" rel="shortcut icon" />
  <link rel="apple-touch-icon" href="/assets/logo_icon128.v101.png"/>
  <link rel="image_src" href="/assets/logo_homepage.normal.v101.png"/>  
  <link type="text/css" media="handheld, all" href="/h1224.css" rel="stylesheet" />
</head>

<body class="body--html">
  <a name="top" id="top"></a>

  <form action="/html/" method="post">
    <input type="text" name="state_hidden" id="state_hidden" />
  </form>

  <div>
    <div class="site-wrapper-border"></div>

    <div id="header" class="header cw header--html">
        <a title="DuckDuckGo" href="/html/" class="header__logo-wrap"></a>


    <form name="x" class="header__form" action="/html/" method="post">

      <div class="search search--header">
          <input name="q" autocomplete="off" class="search__input" id="search_form_input_homepage" type="text" value="mustache.js" />
          <input name="b" id="search_button_homepage" class="search__button search__button--html" value="" title="Search" alt="Search" type="submit" />
      </div>


        
        
        
        
        

    
    
      <input name="kl" value="us-en" type="hidden" />
        
        
    </form>

    </div>


<!-- If zero click results are present -->
    <div class="zci-wrapper">
      <div class="zci">
        <h1 class="zci__heading">
              <a rel="nofollow" href="https://en.wikipedia.org/wiki/Mustache_(template_system)">Mustache (template system)</a>
        </h1>


          <div class="zci__result" id="zero_click_abstract">

  



            Mustache is a simple web template system with implementations available for ActionScript, C++, Clojure, CoffeeScript, ColdFusion, Common Lisp, D, Delphi, Erlang, Fantom, Go, Haskell, Io, Java, JavaScript, Julia, Lua,.NET, Objective-C, Perl, PHP, Pharo, Python, Racket, Ruby, Rust, Scala, Swift, CFEngine and XQuery.
            
            <a rel="nofollow" href="https://en.wikipedia.org/wiki/Mustache_(template_system)" >More at <q>Wikipedia</q></a>
          
          </div>

      </div>
    </div>




<!-- Web results are present -->

  <div>
  <div class="results-wrapper">
  <div id="links" class="results">

      



  

    

        <div class="result results_links results_links_deep result--ad ">

          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTEzNzY1NzQzNTM3Jmx0PTImZXM9ZVVTaDk0UUdQUzliS0hRLSZqZT04ZDU2MjJkMi1iMjJkLTExZTYtYjFhYi0wMDhjZmE1YjU2NWMtN2ZiYWNhZTM4NzAwJnVpPTE0Mi4xMjguMS4xJmp0PTE0Nzk5ODE5Mzk1ODgmcHA9bjE-/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3QngnItT0q_eo26bB03_qkjVUCUxLjNMSshksBtV0wgyWDkeSHjs_jcBK70X873l3w9Ij7PIRwjuz-Img_BXNoL70SgjzRRmZGpAYKelsYIW-U4EscqpNfiUCnhpanvb5yPqMKJdhzf_fQqau_MAj2vMYRbE%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dstache%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d13765743537%2526hvqmt%253dp%2526hvbmt%253dbp%2526hvdev%253dc%2526ref%253dpd_sl_6f5rlseumt_p/RK=0/RS=3fKcWaRGKahkaq9l48MbGqhcvGs-">Stache at Amazon.ca</a>
          
            <a class="result__badge  badge--ad" href="https://duck.co/help/company/advertising-and-affiliates">Ad</a>
          </h2>

          

      
            <a class="result__snippet" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTEzNzY1NzQzNTM3Jmx0PTImZXM9ZVVTaDk0UUdQUzliS0hRLSZqZT04ZDU2MjJkMi1iMjJkLTExZTYtYjFhYi0wMDhjZmE1YjU2NWMtN2ZiYWNhZTM4NzAwJnVpPTE0Mi4xMjguMS4xJmp0PTE0Nzk5ODE5Mzk1ODgmcHA9bjE-/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3QngnItT0q_eo26bB03_qkjVUCUxLjNMSshksBtV0wgyWDkeSHjs_jcBK70X873l3w9Ij7PIRwjuz-Img_BXNoL70SgjzRRmZGpAYKelsYIW-U4EscqpNfiUCnhpanvb5yPqMKJdhzf_fQqau_MAj2vMYRbE%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dstache%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d13765743537%2526hvqmt%253dp%2526hvbmt%253dbp%2526hvdev%253dc%2526ref%253dpd_sl_6f5rlseumt_p/RK=0/RS=3fKcWaRGKahkaq9l48MbGqhcvGs-">Low prices and a huge selection. Qualified Orders Over $35 Ship Free.</a>
      

            
            <div class="result__extras">
                <div class="result__extras__url">

<!-- Disable Ad Favicon
                  <span class="result__icon">
                    
                      <a rel="nofollow" class="result__icon__img" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTEzNzY1NzQzNTM3Jmx0PTImZXM9ZVVTaDk0UUdQUzliS0hRLSZqZT04ZDU2MjJkMi1iMjJkLTExZTYtYjFhYi0wMDhjZmE1YjU2NWMtN2ZiYWNhZTM4NzAwJnVpPTE0Mi4xMjguMS4xJmp0PTE0Nzk5ODE5Mzk1ODgmcHA9bjE-/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3QngnItT0q_eo26bB03_qkjVUCUxLjNMSshksBtV0wgyWDkeSHjs_jcBK70X873l3w9Ij7PIRwjuz-Img_BXNoL70SgjzRRmZGpAYKelsYIW-U4EscqpNfiUCnhpanvb5yPqMKJdhzf_fQqau_MAj2vMYRbE%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dstache%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d13765743537%2526hvqmt%253dp%2526hvbmt%253dbp%2526hvdev%253dc%2526ref%253dpd_sl_6f5rlseumt_p/RK=0/RS=3fKcWaRGKahkaq9l48MbGqhcvGs-">
                        <img width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/.ico" name="i15" />
                      </a>
                  
                  </span>
-->

                  <a class="result__url" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTEzNzY1NzQzNTM3Jmx0PTImZXM9ZVVTaDk0UUdQUzliS0hRLSZqZT04ZDU2MjJkMi1iMjJkLTExZTYtYjFhYi0wMDhjZmE1YjU2NWMtN2ZiYWNhZTM4NzAwJnVpPTE0Mi4xMjguMS4xJmp0PTE0Nzk5ODE5Mzk1ODgmcHA9bjE-/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f0.r.bat.bing.com%2f%3fld%3dd3QngnItT0q_eo26bB03_qkjVUCUxLjNMSshksBtV0wgyWDkeSHjs_jcBK70X873l3w9Ij7PIRwjuz-Img_BXNoL70SgjzRRmZGpAYKelsYIW-U4EscqpNfiUCnhpanvb5yPqMKJdhzf_fQqau_MAj2vMYRbE%26u%3dhttp%253a%252f%252fwww.amazon.ca%252fs%252f%253fie%253dUTF8%2526keywords%253dstache%2526tag%253dmsncahydra-20%2526index%253daps%2526hvadid%253d13765743537%2526hvqmt%253dp%2526hvbmt%253dbp%2526hvdev%253dc%2526ref%253dpd_sl_6f5rlseumt_p/RK=0/RS=3fKcWaRGKahkaq9l48MbGqhcvGs-">
                  amazon.ca
                  </a>

                  

                </div>
            </div>
            


        <div style="clear: both"></div>
          </div>


        </div>

    

  



  

    

        <div class="result results_links results_links_deep result--ad result--ad--small">

          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTQ2NzQ5MTI3NDYmbHQ9MiZlcz1oMDBPZDJBR1BTLm51aEN2JmplPThkNTYyMmQyLWIyMmQtMTFlNi1iMWFiLTAwOGNmYTViNTY1Yy03ZmJhY2FlMzg3MDAmdWk9MTQyLjEyOC4xLjEmanQ9MTQ3OTk4MTkzOTU4OCZwcD1uMg--/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f24791.r.bat.bing.com%2f%3fld%3dd3-5zyqAek891JCe2LtkmtdTVUCUy_RIEdBBpNI_IOoMR_If6gJtYBTPcfz2dVPSVgIdfM3ZAV6aD9Q44ftm6M66ArCqXXdjM0VHVEhMpKBNGDt736TO7BcgWdo8lqnXkCgKgm9ayyPil78WcM-TEtD-n0jl0%26u%3dwww.customizedgirl.com%252fsearch%252fmustache%252byou%252ba%252bquestion%2526utm_source%253dbing%2526utm_medium%253dcpc%2526utm_campaign%253dExperimental%2525202012%2526utm_term%253dmustache%252520you%252520a%252520question%252520tshirt%2526utm_content%253dMustache%252520You%252520a%252520Question/RK=0/RS=1bcfz2iuCxsMgdrytpd7.IyRE8U-">I Mustache You a Question</a>
          
            <a class="result__badge  badge--ad" href="https://duck.co/help/company/advertising-and-affiliates">Ad</a>
          </h2>

          
              <a class="result__url sep--after" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTQ2NzQ5MTI3NDYmbHQ9MiZlcz1oMDBPZDJBR1BTLm51aEN2JmplPThkNTYyMmQyLWIyMmQtMTFlNi1iMWFiLTAwOGNmYTViNTY1Yy03ZmJhY2FlMzg3MDAmdWk9MTQyLjEyOC4xLjEmanQ9MTQ3OTk4MTkzOTU4OCZwcD1uMg--/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f24791.r.bat.bing.com%2f%3fld%3dd3-5zyqAek891JCe2LtkmtdTVUCUy_RIEdBBpNI_IOoMR_If6gJtYBTPcfz2dVPSVgIdfM3ZAV6aD9Q44ftm6M66ArCqXXdjM0VHVEhMpKBNGDt736TO7BcgWdo8lqnXkCgKgm9ayyPil78WcM-TEtD-n0jl0%26u%3dwww.customizedgirl.com%252fsearch%252fmustache%252byou%252ba%252bquestion%2526utm_source%253dbing%2526utm_medium%253dcpc%2526utm_campaign%253dExperimental%2525202012%2526utm_term%253dmustache%252520you%252520a%252520question%252520tshirt%2526utm_content%253dMustache%252520You%252520a%252520Question/RK=0/RS=1bcfz2iuCxsMgdrytpd7.IyRE8U-">
              customizedgirl.com
              </a>
          

      
            <a class="result__snippet" href="https://r.search.yahoo.com/cbclk/dWU9Q0E4M0E3MDFDNkU2NDE3QSZ1dD0xNDc5OTgxOTM5NTc0JnVvPTQ2NzQ5MTI3NDYmbHQ9MiZlcz1oMDBPZDJBR1BTLm51aEN2JmplPThkNTYyMmQyLWIyMmQtMTFlNi1iMWFiLTAwOGNmYTViNTY1Yy03ZmJhY2FlMzg3MDAmdWk9MTQyLjEyOC4xLjEmanQ9MTQ3OTk4MTkzOTU4OCZwcD1uMg--/RV=2/RE=1480010739/RO=10/RU=https%3a%2f%2f24791.r.bat.bing.com%2f%3fld%3dd3-5zyqAek891JCe2LtkmtdTVUCUy_RIEdBBpNI_IOoMR_If6gJtYBTPcfz2dVPSVgIdfM3ZAV6aD9Q44ftm6M66ArCqXXdjM0VHVEhMpKBNGDt736TO7BcgWdo8lqnXkCgKgm9ayyPil78WcM-TEtD-n0jl0%26u%3dwww.customizedgirl.com%252fsearch%252fmustache%252byou%252ba%252bquestion%2526utm_source%253dbing%2526utm_medium%253dcpc%2526utm_campaign%253dExperimental%2525202012%2526utm_term%253dmustache%252520you%252520a%252520question%252520tshirt%2526utm_content%253dMustache%252520You%252520a%252520Question/RK=0/RS=1bcfz2iuCxsMgdrytpd7.IyRE8U-">Shirts, Crewnecks, Pinnies, Tanks & More! Add Your Own Text & Mustaches</a>
      

            


        <div style="clear: both"></div>
          </div>


        </div>

    

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://mustache.github.io/">{{ mustache }}</a>
          
          </h2>

      
            <a class="result__snippet" href="https://mustache.github.io/">IRC: #{on Freenode. Mailing list: mustache@librelist.com. GitHub pages: https://github.com/mustache/mustache.github.com</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://mustache.github.io/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/mustache.github.io.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://mustache.github.io/">
                  mustache.github.io
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://github.com/janl/mustache.js/">GitHub - janl/mustache.js: Minimal templating with {{mustaches}} in ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://github.com/janl/mustache.js/">What could be more logical awesome than no logic at all? <b>mustache.js</b> is an implementation of the mustache template system in JavaScript. Mustache is a logic-less ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://github.com/janl/mustache.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/github.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://github.com/janl/mustache.js/">
                  github.com/janl/mustache.js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://coenraets.org/blog/2011/12/tutorial-html-templates-with-mustache-js/">Tutorial: HTML Templates with <b>Mustache.js</b> - coenraets</a>
          
          </h2>

      
            <a class="result__snippet" href="http://coenraets.org/blog/2011/12/tutorial-html-templates-with-mustache-js/">When developing modern HTML applications, you often write a lot of HTML fragments programmatically. You concatenate HTML tags and dynamic data, and insert the ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://coenraets.org/blog/2011/12/tutorial-html-templates-with-mustache-js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/coenraets.org.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://coenraets.org/blog/2011/12/tutorial-html-templates-with-mustache-js/">
                  coenraets.org/blog/2011/12/tutorial-html-templates-with...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.sitepoint.com/creating-html-templates-with-mustachejs/">Creating HTML Templates with <b>Mustache.js</b> - SitePoint</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.sitepoint.com/creating-html-templates-with-mustachejs/">This article provides an introduction to HTML templating in <b>mustache.js</b>.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.sitepoint.com/creating-html-templates-with-mustachejs/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.sitepoint.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.sitepoint.com/creating-html-templates-with-mustachejs/">
                  sitepoint.com/creating-html-templates-with-mustachejs/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://cdnjs.com/libraries/mustache.js/"><b>mustache.js</b> - cdnjs.com - The best FOSS CDN for web related libraries ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://cdnjs.com/libraries/mustache.js/"><b>mustache.js</b> - Logic-less {{mustache}} templates with JavaScript - cdnjs.com - The best FOSS CDN for web related libraries to speed up your websites!</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://cdnjs.com/libraries/mustache.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/cdnjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://cdnjs.com/libraries/mustache.js/">
                  cdnjs.com/libraries/mustache.js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.npmjs.com/package/mustache"><b>Mustache.js</b> - npm</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.npmjs.com/package/mustache">Command line tool. <b>mustache.js</b> is shipped with a node based command line tool. It might be installed as a global tool on your computer to render a mustache template ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.npmjs.com/package/mustache">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.npmjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.npmjs.com/package/mustache">
                  npmjs.com/package/mustache
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://handlebarsjs.com/">Handlebars.js: Minimal Templating on Steroids</a>
          
          </h2>

      
            <a class="result__snippet" href="http://handlebarsjs.com/">Handlebars provides the power necessary to let you build semantic templates effectively with no frustration. Handlebars is largely compatible with ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://handlebarsjs.com/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/handlebarsjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://handlebarsjs.com/">
                  handlebarsjs.com
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://mustache.github.io/mustache.5.html">mustache(5) - Logic-less templates.</a>
          
          </h2>

      
            <a class="result__snippet" href="https://mustache.github.io/mustache.5.html">mustache(5) Mustache Manual; mustache(5) NAME. mustache - Logic-less templates. SYNOPSIS. A typical Mustache template: Hello {{name}} You have just won {{value ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://mustache.github.io/mustache.5.html">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/mustache.github.io.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://mustache.github.io/mustache.5.html">
                  mustache.github.io/mustache.5.html
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://code.tutsplus.com/tutorials/using-the-mustache-template-library--net-14590">Using the Mustache Template Library - code.tutsplus.com</a>
          
          </h2>

      
            <a class="result__snippet" href="https://code.tutsplus.com/tutorials/using-the-mustache-template-library--net-14590">For the data part, <b>Mustache.js</b> requires a function that returns the function to be used. That function gets passed the text to be rendered ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://code.tutsplus.com/tutorials/using-the-mustache-template-library--net-14590">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/code.tutsplus.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://code.tutsplus.com/tutorials/using-the-mustache-template-library--net-14590">
                  code.tutsplus.com/tutorials/using-the-mustache-template-lib...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://en.wikipedia.org/wiki/Mustache_%28template_system%29">Mustache (template system) - Wikipedia</a>
          
          </h2>

      
            <a class="result__snippet" href="https://en.wikipedia.org/wiki/Mustache_%28template_system%29">History and principles. Mustache-1 was inspired by ctemplate and et, and started as a GitHub distribution at the end of 2009. A first version of the template engine ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://en.wikipedia.org/wiki/Mustache_%28template_system%29">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/en.wikipedia.org.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://en.wikipedia.org/wiki/Mustache_%28template_system%29">
                  en.wikipedia.org/wiki/Mustache_(template_system)
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://writing.jan.io/mustache-2.0.html">Mustache 2.0 and the Future of <b>Mustache.js</b> - Writing</a>
          
          </h2>

      
            <a class="result__snippet" href="http://writing.jan.io/mustache-2.0.html">Mustache 2.0 and the Future of <b>Mustache.js</b> ↤ February 13 th, 2011. Dear Mustache community, users and implementors: This is a lengthy call to arms; in short: I need ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://writing.jan.io/mustache-2.0.html">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/writing.jan.io.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://writing.jan.io/mustache-2.0.html">
                  writing.jan.io/mustache-2.0.html
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.lynda.com/articles/introduction-to-javascript-templating-using-mustache-js">Introduction to JavaScript templating using <b>mustache.js</b></a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.lynda.com/articles/introduction-to-javascript-templating-using-mustache-js">By Ray Villalobos | Thursday, December 27, 2012. Introduction to JavaScript templating using <b>mustache.js</b>. Recently I built a small website for an event in my area.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.lynda.com/articles/introduction-to-javascript-templating-using-mustache-js">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.lynda.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.lynda.com/articles/introduction-to-javascript-templating-using-mustache-js">
                  lynda.com/articles/introduction-to-javascript-templ...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://github.com/janl/mustache.js/blob/master/README.md">mustache.js/README.md at master · janl/mustache.js · GitHub</a>
          
          </h2>

      
            <a class="result__snippet" href="https://github.com/janl/mustache.js/blob/master/README.md">What could be more logical awesome than no logic at all? <b>mustache.js</b> is an implementation of the mustache template system in JavaScript. Mustache is a logic-less ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://github.com/janl/mustache.js/blob/master/README.md">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/github.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://github.com/janl/mustache.js/blob/master/README.md">
                  github.com/janl/mustache.js/blob/master/README.md
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.lynda.com/Mustache-js-training-tutorials/2052-0.html"><b>Mustache.js</b> - Lynda.com</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.lynda.com/Mustache-js-training-tutorials/2052-0.html"><b>Mustache.js</b> Training and Tutorials. Learn how to use <b>Mustache.js</b>, from beginner basics to advanced techniques, with online video tutorials taught by industry experts.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.lynda.com/Mustache-js-training-tutorials/2052-0.html">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.lynda.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.lynda.com/Mustache-js-training-tutorials/2052-0.html">
                  lynda.com/Mustache-js-training-tutorials/2052-0.html
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.nuget.org/packages/mustache.js/">NuGet Gallery | <b>mustache.js</b> 0.7.2</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.nuget.org/packages/mustache.js/">Contact Us. Got questions about NuGet or the NuGet Gallery? Overview. NuGet is a Visual Studio extension that makes it easy to add, remove, and update libraries and...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.nuget.org/packages/mustache.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.nuget.org.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.nuget.org/packages/mustache.js/">
                  nuget.org/packages/mustache.js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.onextrapixel.com/2015/02/10/mustache-js-what-makes-this-template-system-so-resourceful/"><b>Mustache.js</b>: What Makes This Template System So Resourceful - Onextrapixel</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.onextrapixel.com/2015/02/10/mustache-js-what-makes-this-template-system-so-resourceful/">To put it in learner&#x27;s terms, Mustache is a web template system. But as you would expect, it is more advanced than its counterparts and does involve a fair mix of new ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.onextrapixel.com/2015/02/10/mustache-js-what-makes-this-template-system-so-resourceful/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.onextrapixel.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.onextrapixel.com/2015/02/10/mustache-js-what-makes-this-template-system-so-resourceful/">
                  onextrapixel.com/2015/02/10/mustache-js-what-makes-this-te...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://stackoverflow.com/questions/6027525/how-do-i-accomplish-an-if-else-in-mustache-js">How do I accomplish an if/else in <b>mustache.js</b>? - Stack Overflow</a>
          
          </h2>

      
            <a class="result__snippet" href="http://stackoverflow.com/questions/6027525/how-do-i-accomplish-an-if-else-in-mustache-js">How do I accomplish an if/else in <b>mustache.js</b>? up vote 175 down vote favorite. 23. It seems rather odd that I can&#x27;t figure how to do this in mustache. Is it supported?</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://stackoverflow.com/questions/6027525/how-do-i-accomplish-an-if-else-in-mustache-js">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/stackoverflow.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://stackoverflow.com/questions/6027525/how-do-i-accomplish-an-if-else-in-mustache-js">
                  stackoverflow.com/questions/6027525/how-do-i-accomplish-an-...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.linuxjournal.com/content/mustachejs"><b>Mustache.js</b> | Linux Journal</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.linuxjournal.com/content/mustachejs">In previous articles, I&#x27;ve looked at a number of uses for JavaScript, on both the server and the client. I hope to continue my exploration of such systems ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.linuxjournal.com/content/mustachejs">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.linuxjournal.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.linuxjournal.com/content/mustachejs">
                  linuxjournal.com/content/mustachejs
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://canjs.com/docco/view/mustache/mustache.html"><b>mustache.js</b> - CanJS</a>
          
          </h2>

      
            <a class="result__snippet" href="https://canjs.com/docco/view/mustache/mustache.html"><b>mustache.js</b>. can.Mustache: The Mustache templating engine. See the Transformation section within Scanning Helpers for a detailed explanation of the runtime render ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://canjs.com/docco/view/mustache/mustache.html">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/canjs.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://canjs.com/docco/view/mustache/mustache.html">
                  canjs.com/docco/view/mustache/mustache.html
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.va.gov/TRM/ToolPage.asp?tid=8858"><b>mustache.js</b> - United States Department of Veterans Affairs</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.va.gov/TRM/ToolPage.asp?tid=8858">Website: Go to site: Description: <b>Mustache.js</b> is an implementation of the mustache template system in JavaScript. A mustache template is a string that contains any ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.va.gov/TRM/ToolPage.asp?tid=8858">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.va.gov.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.va.gov/TRM/ToolPage.asp?tid=8858">
                  va.gov/TRM/ToolPage.asp?tid=8858
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://stackoverflow.com/questions/10555820/what-are-the-differences-between-mustache-js-and-handlebars-js">What are the differences between <b>Mustache.js</b> and Handlebars.js? - Stack ...</a>
          
          </h2>

      
            <a class="result__snippet" href="http://stackoverflow.com/questions/10555820/what-are-the-differences-between-mustache-js-and-handlebars-js">Major differences I&#x27;ve seen are: Handlebars templates are compiled Handlebars adds #if, #unless, #with, and #each Handlebars adds helpers Handlebars supports paths ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://stackoverflow.com/questions/10555820/what-are-the-differences-between-mustache-js-and-handlebars-js">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/stackoverflow.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://stackoverflow.com/questions/10555820/what-are-the-differences-between-mustache-js-and-handlebars-js">
                  stackoverflow.com/questions/10555820/what-are-the-differenc...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.c-sharpcorner.com/uploadfile/abhikumarvatsa/getting%2Dstarted%2Dwith%2Dmustache%2Djs%2Din%2Dmvc/">Getting Started With <b>Mustache.js</b> in MVC - C# Corner</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.c-sharpcorner.com/uploadfile/abhikumarvatsa/getting%2Dstarted%2Dwith%2Dmustache%2Djs%2Din%2Dmvc/">In this article you will learn how to use the <b>Mustache.js</b> JavaScript library in MVC for client-side templating.</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.c-sharpcorner.com/uploadfile/abhikumarvatsa/getting%2Dstarted%2Dwith%2Dmustache%2Djs%2Din%2Dmvc/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.c-sharpcorner.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.c-sharpcorner.com/uploadfile/abhikumarvatsa/getting%2Dstarted%2Dwith%2Dmustache%2Djs%2Din%2Dmvc/">
                  c-sharpcorner.com/uploadfile/abhikumarvatsa/getting-started...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://allmychanges.com/p/javascript/mustache.js/">javascript/mustache.js&#x27;s changelog at AllMyChanges.com, release notes ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://allmychanges.com/p/javascript/mustache.js/">Mustache.Js&#x27;s release notes. Minimal templating with {{mustaches}} in JavaScript</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://allmychanges.com/p/javascript/mustache.js/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/allmychanges.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://allmychanges.com/p/javascript/mustache.js/">
                  allmychanges.com/p/javascript/mustache.js/
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://docs.ractivejs.org/latest/mustaches">Mustaches | Docs | Ractive.js</a>
          
          </h2>

      
            <a class="result__snippet" href="http://docs.ractivejs.org/latest/mustaches">Mustaches edit this page What is Mustache? Mustache is one of the most popular templating languages. It&#x27;s a very lightweight, readable syntax with a comprehensive ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://docs.ractivejs.org/latest/mustaches">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/docs.ractivejs.org.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://docs.ractivejs.org/latest/mustaches">
                  docs.ractivejs.org/latest/mustaches
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://www.youtube.com/watch?v=JlmoQBF2lvw">How to use <b>Mustache.js</b> Template System - YouTube</a>
          
          </h2>

      
            <a class="result__snippet" href="http://www.youtube.com/watch?v=JlmoQBF2lvw">Want to watch this again later? Sign in to add this video to a playlist. Mustache is an awesome template engine that can be used in Javascript, PHP, Ruby ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://www.youtube.com/watch?v=JlmoQBF2lvw">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.youtube.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://www.youtube.com/watch?v=JlmoQBF2lvw">
                  youtube.com/watch?v=JlmoQBF2lvw
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.quora.com/Why-use-mustache-js-or-hogan-js?share=1">Why use <b>mustache.js</b> or hogan.js? - Quora</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.quora.com/Why-use-mustache-js-or-hogan-js?share=1">Is it possible to use a templating system like <b>mustache.js</b>, handlebars.js with angular.js? Why should I use a templating system?</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.quora.com/Why-use-mustache-js-or-hogan-js?share=1">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.quora.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.quora.com/Why-use-mustache-js-or-hogan-js?share=1">
                  quora.com/Why-use-mustache-js-or-hogan-js?share=1
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="http://blog.xoundboy.com/?p=535">How to use Mustache with JS / jQuery - a working example</a>
          
          </h2>

      
            <a class="result__snippet" href="http://blog.xoundboy.com/?p=535">How to use Mustache with JS / jQuery - a ... js&quot; type = &quot;text/javascript&quot; &gt; &lt; / script &gt; &lt; script src = &quot;<b>mustache.js</b>&quot; type = &quot;text/javascript&quot; &gt;&lt; / script ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="http://blog.xoundboy.com/?p=535">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/blog.xoundboy.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="http://blog.xoundboy.com/?p=535">
                  blog.xoundboy.com/?p=535
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.nuget.org/packages?q=Mustache">NuGet Gallery | Packages matching Mustache</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.nuget.org/packages?q=Mustache"><b>Mustache.js</b> compliant templating engine ... Handlebars.js and Mustache are both logicless templating languages that keep the view and the code separated like we all ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.nuget.org/packages?q=Mustache">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.nuget.org.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.nuget.org/packages?q=Mustache">
                  nuget.org/packages?q=Mustache
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://www.quora.com/Is-it-possible-to-use-a-templating-system-like-mustache-js-handlebars-js-with-angular-js-Why-should-I-use-a-templating-system?share=1">Is it possible to use a templating system like <b>mustache.js</b> ... - Quora</a>
          
          </h2>

      
            <a class="result__snippet" href="https://www.quora.com/Is-it-possible-to-use-a-templating-system-like-mustache-js-handlebars-js-with-angular-js-Why-should-I-use-a-templating-system?share=1">Is it possible to use a templating system like <b>mustache.js</b>, handlebars.js with angular.js? Why should I use a templating system?</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://www.quora.com/Is-it-possible-to-use-a-templating-system-like-mustache-js-handlebars-js-with-angular-js-Why-should-I-use-a-templating-system?share=1">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/www.quora.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://www.quora.com/Is-it-possible-to-use-a-templating-system-like-mustache-js-handlebars-js-with-angular-js-Why-should-I-use-a-templating-system?share=1">
                  quora.com/Is-it-possible-to-use-a-templating-system...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  



  


            <div class="result results_links results_links_deep web-result ">


          <div class="links_main links_deep result__body"> <!-- This is the visible part -->

          <h2 class="result__title">
          
            <a rel="nofollow" class="result__a" href="https://strongloop.com/strongblog/compare-javascript-templates-jade-mustache-dust/">StrongLoop | Comparing JavaScript Templating Engines: Jade, Mustache ...</a>
          
          </h2>

      
            <a class="result__snippet" href="https://strongloop.com/strongblog/compare-javascript-templates-jade-mustache-dust/">EJS and <b>Mustache.js</b> get a break here because they are fairly simple and there ... Jade allows for full JavaScript expressions but makes that just awkward enough to ...</a>
      

      

            <div class="result__extras">
                <div class="result__extras__url">
                  <span class="result__icon">
                    
                      <a rel="nofollow" href="https://strongloop.com/strongblog/compare-javascript-templates-jade-mustache-dust/">
                        <img class="result__icon__img" width="16" height="16" alt=""
                          src="//icons.duckduckgo.com/ip2/strongloop.com.ico" name="i15" />
                      </a>
                  
                  </span>

                  <a class="result__url" href="https://strongloop.com/strongblog/compare-javascript-templates-jade-mustache-dust/">
                  strongloop.com/strongblog/compare-javascript-templates-j...
                  </a>

                  

                </div>
            </div>

            <div style="clear: both"></div>
          </div>

        </div>

  




        
        
                <div class="nav-link">
        <form action="/html/" method="post">
          <input type="submit" class='btn btn--alt' value="Next" />
          <input type="hidden" name="q" value="mustache.js" />
          <input type="hidden" name="s" value="30" />
          <input type="hidden" name="nextParams" value="Keywords=mustache.js&amp;xargs=12KPjg1slSrZquh831MeKMQeGUgRpd1tm58d0uXsYsfIwUpX9v6dFIEOacyZA6QO1xt77k%5FcDYpflNaKymwfaJExjXBRHcX726gZS7%5FYsrb%2DeWZZIezeZgn7Sy2tkTZXIFYk%2DBSQ%2E%2E&amp;hData=12KPjg1qdOxJy7tuqnF9W2TOuj8m4%2E" />
          <input type="hidden" name="v" value="l" />
          <input type="hidden" name="o" value="json" />
          <input type="hidden" name="dc" value="33" />
          <input type="hidden" name="api" value="/d.js" />

            
            
        
          <input name="kl" value="us-en" type="hidden" />
            
            
            
            
            
        </form>
                </div>
        



        <div class=" feedback-btn">
            <a rel="nofollow" href="/feedback.html" target="_new">Feedback</a>
        </div>
        <div style="clear:both;"></div>
  </div>
  </div> <!-- links wrapper //--> 

    



    </div>
  </div>




    <div id="bottom_spacing2"></div>

    
      <img src="/t/sl_h"/>
    

</body>
</html>
